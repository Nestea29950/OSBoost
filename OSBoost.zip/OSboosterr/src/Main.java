import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.geom.RoundRectangle2D;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.Reader;
import java.lang.ProcessBuilder.Redirect;
import java.net.URL;
import java.util.Scanner;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.TitledBorder;
import javax.swing.SwingConstants;
import javax.swing.JTextPane;
import javax.swing.JTextArea;

public class Main {

	private JFrame frame;
	private JTextArea textArea;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main window = new Main();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Main() {
		initialize();
	}
	private Point initialClick;
  
	
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				initialClick = e.getPoint();
	            getComponentAt(initialClick);
				
				
			}
		});
		frame.getContentPane().addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseDragged(MouseEvent e) {
				// get location of Window
	            int thisX = frame.getLocation().x;
	            int thisY = frame.getLocation().y;

	            // Determine how much the mouse moved since the initial click
	            int xMoved = e.getX() - initialClick.x;
	            int yMoved = e.getY() - initialClick.y;

	            // Move window to this position
	            int X = thisX + xMoved;
	            int Y = thisY + yMoved;
	            frame.setLocation(X, Y);
				
				
			}
		});
		
		frame.setUndecorated(true);
		frame.setShape(new RoundRectangle2D.Double(10, 10, 800, 480, 20, 20));
		frame.getContentPane().setBackground(new Color(26, 26, 26));
		frame.setBounds(100, 100, 828, 502);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setForeground(new Color(20, 20, 20));
		
		panel.setBackground(new Color(51, 51, 51));
		panel.setBounds(10, 0, 125, 500);
		panel.setBorder(new BevelBorder(BevelBorder.RAISED, new Color(20, 20, 20), null, null, null));
		
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Tools");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setBounds(42, 23, 46, 14);
		panel.add(lblNewLabel_1);
		
		JButton Windows = new JButton("");
		Windows.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int dialogButton = JOptionPane.YES_NO_OPTION;
				dialogButton = JOptionPane.showConfirmDialog (null, "Voulez vous d�sactiv� les fonctionnalit� Windows ?", "Fonctionnalit� Windows", dialogButton);
				
				 if (JOptionPane.showConfirmDialog(null, "Etes vous sur ?", "Fonctionnalit� Windows",
					        JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
					 try {
							Process p = Runtime.getRuntime().exec("cmd /c start " + Main.class.getResource("/res/F-Windows-10.bat"));
							Process g = Runtime.getRuntime().exec("regedit start" + Main.class.getResource("/res/.reg//OSboosterr/src/res/reg/Turn_Off_Background_Apps.reg.reg" ));
						} catch (IOException e1) {
							e1.printStackTrace();
						}
					 try {
						Thread.sleep(000);
					} catch (InterruptedException e2) {
						// TODO Bloc catch g�n�r� automatiquement
						e2.printStackTrace();
					}
					 JOptionPane.showMessageDialog(frame, "R�ussie !");
					} else {}
			}
		});
		Windows.setIcon(new ImageIcon(Main.class.getResource("/icon/iconmonstr-windows-os-1-24.png")));
		Windows.setBounds(30, 65, 58, 32);
		panel.add(Windows);
		Windows.setForeground(new Color(31, 31, 31));
		Windows.setBackground(new Color(31, 31, 31));
		Windows.setOpaque(false);
		Windows.setBorderPainted(false);
		Windows.setContentAreaFilled(false);
		Windows.setBackground(new Color(255,255,255,0));
		Windows.setFocusPainted(false);
		
		JButton Supply = new JButton("");
		Supply.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int dialogButton = JOptionPane.YES_NO_OPTION;
				dialogButton = JOptionPane.showConfirmDialog (null, "Voulez vous mettre les performance en mode �lev�e ?", "Performance �lev�e", dialogButton);
				
				 if (JOptionPane.showConfirmDialog(null, "Etes vous sur ?", "Performance �lev�e",
					        JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
					 try {
							Process p = Runtime.getRuntime().exec("cmd /c start " + Main.class.getResource("/res/Supply.bat"));
						} catch (IOException e1) {
							e1.printStackTrace();
						}
					 try {
							Thread.sleep(2000);
						} catch (InterruptedException e2) {
							// TODO Bloc catch g�n�r� automatiquement
							e2.printStackTrace();
						}
					 JOptionPane.showMessageDialog(frame, "R�ussie !");
					} else {}
			}
		});
		Supply.setIcon(new ImageIcon(Main.class.getResource("/icon/iconmonstr-flash-thin-24 (1).png")));
		Supply.setBounds(30, 116, 58, 32);
		Supply.setOpaque(false);
		Supply.setBorderPainted(false);
		Supply.setContentAreaFilled(false);
		Supply.setBackground(new Color(255,255,255,0));
		Supply.setFocusPainted(false);
		panel.add(Supply);
		
		JButton Key = new JButton("");
		Key.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int dialogButton = JOptionPane.YES_NO_OPTION;
				
				dialogButton = JOptionPane.showConfirmDialog (null, "Voulez vous activ� Windows 10 ?", "Activation Windows 10", dialogButton);
				 if (JOptionPane.showConfirmDialog(null, "Etes vous sur ?", "Activation Windows 10",
					        JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
					 try {
							Process p = Runtime.getRuntime().exec("cmd /c start " +Main.class.getResource("/res/ActivateWindows.bat"));
						} catch (IOException e1) {
							e1.printStackTrace();
							try {
								Thread.sleep(2000);
							} catch (InterruptedException e2) {
								// TODO Bloc catch g�n�r� automatiquement
								e2.printStackTrace();
							}
							JOptionPane.showMessageDialog(frame, "R�ussie !");
						}
					} else {
					}
			}
				
		});
		Key.setIcon(new ImageIcon(Main.class.getResource("/icon/iconmonstr-key-1-24.png")));
		Key.setBounds(30, 170, 58, 32);
		Key.setOpaque(false);
		Key.setBorderPainted(false);
		Key.setContentAreaFilled(false);
		Key.setBackground(new Color(255,255,255,0));
		Key.setFocusPainted(false);
		panel.add(Key);
		
		JButton Cortana = new JButton("");
		Cortana.setIcon(new ImageIcon(Main.class.getResource("/icon/iconmonstr-circle-4-24.png")));
		Cortana.setBounds(30, 224, 58, 32);
		panel.add(Cortana);
		Cortana.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int dialogButton = JOptionPane.YES_NO_OPTION;
				dialogButton = JOptionPane.showConfirmDialog (null, "Voulez vous d�sactiver cortana?", "D�sactivation Cortana", dialogButton);
				 if (JOptionPane.showConfirmDialog(null, "Etes vous sur ?", "D�sactivation Cortana",
					        JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
					 try {
						 Process p = Runtime.getRuntime().exec("regedit start" + Main.class.getResource("/res/.reg/Disable_Cortana.reg"));
						} catch (IOException e1) {
							e1.printStackTrace();
							try {
								Thread.sleep(2000);
							} catch (InterruptedException e2) {
								e2.printStackTrace();
							}
							JOptionPane.showMessageDialog(frame, "R�ussie !");
						}
					} else {
					}
			}
		});
		Cortana.setOpaque(false);
		Cortana.setBorderPainted(false);
		Cortana.setContentAreaFilled(false);
		Cortana.setBackground(new Color(255,255,255,0));
		Cortana.setFocusPainted(false);
		
		JButton Update = new JButton("");
		Update.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent e) {
				
			}
		});
		Update.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int dialogButton = JOptionPane.YES_NO_OPTION;
				String path = Main.class.getResource("/res/ActivateWindows.bat").getPath().substring(1);
				//String path = "/res/UpdateWindows10.bat";
				dialogButton = JOptionPane.showConfirmDialog (null, "Voulez vous d�sactiv� les mises a jours Windows 10 ?", "Update Windows 10", dialogButton);
				 if (JOptionPane.showConfirmDialog(null, "Etes vous sur ?", "Update Windows 10",
					        JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
					 ProcessBuilder p = new ProcessBuilder("cmd", "/c" ,"start " + path);
					 
					 	p.redirectErrorStream(true);

					    Process process = null;
						try {
							process = p.start();
						} catch (IOException e1) {
							// TODO Bloc catch g�n�r� automatiquement
							e1.printStackTrace();
						}

					    OutputStream processStdOutput = process.getOutputStream();
					    Reader r = new OutputStreamReader(processStdOutput);
					    BufferedReader br = new BufferedReader(r);
					    String line;
					    try {
							while ((line = br.readLine()) != null) {
//					      System.out.println(line); // the output is here
							    textArea.append(line);
							}
						} catch (IOException e1) {
							// TODO Bloc catch g�n�r� automatiquement
							e1.printStackTrace();
						}
					}
				
			}
		});
		Update.setIcon(new ImageIcon(Main.class.getResource("/icon/iconmonstr-refresh-3-24.png")));
		Update.setOpaque(false);
		Update.setFocusPainted(false);
		Update.setContentAreaFilled(false);
		Update.setBorderPainted(false);
		Update.setBackground(new Color(255, 255, 255, 0));
		Update.setBounds(30, 282, 58, 32);
		panel.add(Update);
		
		
		JButton Close = new JButton("");
		
		Close.setIcon(new ImageIcon(Main.class.getResource("/icon/iconmonstr-door-5-24.png")));
		
		Close.setForeground(new Color(31, 31, 31));
		Close.setBounds(742, 21, 64, 40);
		Close.setOpaque(false);
		Close.setBorderPainted(false);
		Close.setContentAreaFilled(false);
		Close.setBackground(new Color(255,255,255,0));
		Close.setFocusPainted(false);
		frame.getContentPane().add(Close);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(51, 51, 51));
		panel_1.setBounds(625, 11, 2, 489);
		frame.getContentPane().add(panel_1);
		
		JButton Minimize = new JButton("");
		Minimize.setIcon(new ImageIcon(Main.class.getResource("/icon/iconmonstr-minimize-thin-24.png")));
		Minimize.setBorderPainted(false);
		Minimize.setContentAreaFilled(false);
		Minimize.setBackground(new Color(255,255,255,0));
		Minimize.setFocusPainted(false);
		Minimize.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				frame.setExtendedState(frame.ICONIFIED);
			}
		});
		Minimize.setBounds(686, 21, 64, 40);
		frame.getContentPane().add(Minimize);
		
		JButton help = new JButton("");
		help.setIcon(new ImageIcon(Main.class.getResource("/icon/iconmonstr-help-3-24.png")));
		help.setBounds(635, 21, 64, 40);
		help.setOpaque(false);
		help.setBorderPainted(false);
		help.setContentAreaFilled(false);
		help.setBackground(new Color(255,255,255,0));
		help.setFocusPainted(false);
		frame.getContentPane().add(Close);
		frame.getContentPane().add(help);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon(Main.class.getResource("/icon/Work risk-free (2) (1).png")));
		lblNewLabel_2.setBounds(201, 247, 426, 244);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel = new JLabel("OSBoard");
		lblNewLabel.setBounds(347, 21, 88, 26);
		frame.getContentPane().add(lblNewLabel);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel.setForeground(new Color(255, 255, 255));
		
		 textArea = new JTextArea();
		 textArea.setText("azea");
		 textArea.setBounds(243, 96, 275, 22);
		frame.getContentPane().add(textArea);
		Close.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});
		
		
	}
	protected void getComponentAt(Point initialClick2) {
	}
}
