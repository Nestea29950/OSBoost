import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.geom.RoundRectangle2D;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Point;
import javax.swing.ImageIcon;
import java.awt.Button;
import javax.swing.SwingConstants;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;

public class Main {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main window = new Main();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Main() {
		initialize();
	}
	private Point initialClick;
    
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				initialClick = e.getPoint();
	            getComponentAt(initialClick);
				
				
			}
		});
		frame.getContentPane().addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseDragged(MouseEvent e) {
				// get location of Window
	            int thisX = frame.getLocation().x;
	            int thisY = frame.getLocation().y;

	            // Determine how much the mouse moved since the initial click
	            int xMoved = e.getX() - initialClick.x;
	            int yMoved = e.getY() - initialClick.y;

	            // Move window to this position
	            int X = thisX + xMoved;
	            int Y = thisY + yMoved;
	            frame.setLocation(X, Y);
				
				
			}
		});
		
		frame.setUndecorated(true);
		frame.setShape(new RoundRectangle2D.Double(10, 10, 800, 500, 40, 40));
		frame.getContentPane().setBackground(new Color(31,31,31));
		frame.setBounds(100, 100, 800, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(26, 26, 26));
		panel.setBounds(10, 11, 188, 489);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("OSBoard");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setBounds(21, 11, 88, 26);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Tools");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setBounds(21, 76, 46, 14);
		panel.add(lblNewLabel_1);
		
		JButton Windows = new JButton("");
		Windows.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					Process p = Runtime.getRuntime().exec("cmd /c start C:\\Users\\wgaonarch\\Desktop\\F-Windows-10.bat");
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
		Windows.setIcon(new ImageIcon(Main.class.getResource("/Icon/iconmonstr-windows-os-1-24.png")));
		Windows.setBounds(9, 110, 58, 32);
		panel.add(Windows);
		Windows.setForeground(new Color(31, 31, 31));
		Windows.setBackground(new Color(31, 31, 31));
		Windows.setOpaque(false);
		Windows.setBorderPainted(false);
		Windows.setContentAreaFilled(false);
		Windows.setBackground(new Color(255,255,255,0));
		Windows.setFocusPainted(false);
		
		
		JButton Close = new JButton("");
		
		Close.setIcon(new ImageIcon(Main.class.getResource("/Icon/iconmonstr-door-5-24.png")));
		
		Close.setForeground(new Color(31, 31, 31));
		Close.setBounds(736, 11, 64, 40);
		Close.setOpaque(false);
		Close.setBorderPainted(false);
		Close.setContentAreaFilled(false);
		Close.setBackground(new Color(255,255,255,0));
		Close.setFocusPainted(false);
		frame.getContentPane().add(Close);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(38, 38, 38));
		panel_1.setBounds(625, 11, 2, 489);
		frame.getContentPane().add(panel_1);
		
		JButton Minimize = new JButton("");
		Minimize.setIcon(new ImageIcon(Main.class.getResource("/Icon/iconmonstr-minimize-thin-24.png")));
		Minimize.setBorderPainted(false);
		Minimize.setContentAreaFilled(false);
		Minimize.setBackground(new Color(255,255,255,0));
		Minimize.setFocusPainted(false);
		Minimize.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				frame.setExtendedState(frame.ICONIFIED);
			}
		});
		Minimize.setBounds(686, 11, 64, 40);
		frame.getContentPane().add(Minimize);
		
		JButton help = new JButton("");
		help.setIcon(new ImageIcon(Main.class.getResource("/Icon/iconmonstr-help-3-24.png")));
		help.setBounds(633, 11, 64, 40);
		help.setOpaque(false);
		help.setBorderPainted(false);
		help.setContentAreaFilled(false);
		help.setBackground(new Color(255,255,255,0));
		help.setFocusPainted(false);
		frame.getContentPane().add(Close);
		frame.getContentPane().add(help);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon(Main.class.getResource("/Icon/Work risk-free (1).png")));
		lblNewLabel_2.setBounds(201, 271, 426, 244);
		frame.getContentPane().add(lblNewLabel_2);
		Close.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			
				
				
			}
		});
		
		
	}

	protected void getComponentAt(Point initialClick2) {
		// TODO Stub de la m�thode g�n�r� automatiquement
		
	}
}
